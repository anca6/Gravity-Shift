Thank you for downloading and playing Gravity Shift!

This was created for school: project final approach.
This was created using: GXPEngine2023 (c#).
This was co-created with: 
-Emily Murad (engineer)
-Anca Custura (engineer)
-Maria Pana (artist)
-Stan Westerhof (artist)
-Imme Kolste (artist)
-Daphne Tijhof (designer)
-Kenzo v/d Meulen (designer)

For more information, contact me: www.emilymurad.nl